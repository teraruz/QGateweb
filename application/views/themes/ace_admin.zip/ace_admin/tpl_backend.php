<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta charset="utf-8" />
	<title><?php echo $page_title; ?></title>

	<meta name="description" content="User login page" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

</head>

<body class="no-skin">

	<?php echo $page_header; ?>
	<?php echo $page_menu; ?>




	<?php echo $page_content; ?>



	<?php echo $page_footer; ?>
	</div>



</body>

</html>