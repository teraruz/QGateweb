			<div class="footer">
				<div class="footer-inner">
					<!-- <div class="footer-content"> -->
						<!-- <div class="col-xs-12 col-sm-6"> -->
						<span class="bigger-120">
							<span class="blue bolder">Copyright © TBK Group Company Limited. All rights reserved</span>
							
						</span>
					<!-- </div> -->

						&nbsp; &nbsp;

					<!-- </div> -->
				</div>
			</div>