<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <title></title>
</head>
<body>
  <table border="1" >
    <tr>
      <!-- <td>A</td>
      <td>B</td> -->

      <th>No.</th>
      <th>Username</th>
      <th>Password</th>
      <th>Edit</th>
      <th>Delete</th>
    
    </tr>
  
  <?php
  foreach($resultUser as $value) {
    echo "<tr>";
    echo "<td>".$value["id"]."</td>";
    echo "<td>".$value["user_name"]."</td>";
    echo "<td>".$value["user_password"]."</td>";
    echo "<td><a href='". base_url()."Login/Edituser?id=".$value["id"]."'>Edit</a></td>";
    echo "<td><a href='". base_url()."Login/Deleteuser?id=".$value["id"]."'>Delete</a></td>";
    echo "</tr>";
  }
  ?>
  </table>
</body>
</html>


