<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Login Page - Ace Admin</title>

		<meta name="description" content="User login page" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
		<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
		

		<!-- bootstrap & fontawesome -->
        <link rel="stylesheet" href="<?php echo base_url() . $css_url; ?>bootstrap.min.css" />

        <link rel="stylesheet" href="<?php echo base_url() . $asset_url; ?>font-awesome\4.5.0\css\font-awesome.min.css" />
		<!-- text fonts -->
        <link rel="stylesheet" href="<?php echo base_url() . $css_url; ?>fonts.googleapis.com.css" />
        
		<!-- ace styles -->
		
        <link rel="stylesheet" href="<?php echo base_url() . $css_url; ?>ace.min.css" />
		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" />
		<![endif]-->
        <link rel="stylesheet" href="<?php echo base_url() . $css_url; ?>ace-rtl.min.css" />
       
		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
		<![endif]-->
	</head>

	<body>
	<div class="verticalcenter">
	<a href="index.htm"><img src="assets/img/logo-big.png" alt="Logo" class="brand" /></a>
	<div class="panel panel-primary">
		<div class="panel-body">
			<h4 class="text-center" style="margin-bottom: 25px;">Log in to get started or <a href="extras-signupform.htm">Sign Up</a></h4>
				<form action="#" class="form-horizontal" style="margin-bottom: 0px !important;">
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user"></i></span>
									<input type="text" class="form-control" id="username" placeholder="Username">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock"></i></span>
									<input type="password" class="form-control" id="password" placeholder="Password">
								</div>
							</div>
						</div>
						<div class="clearfix">
							<div class="pull-right"><label><input type="checkbox" style="margin-bottom: 20px" checked=""> Remember Me</label></div>
						</div>
					</form>
					
		</div>
		<div class="panel-footer">
			<a href="extras-forgotpassword.htm" class="pull-left btn btn-link" style="padding-left:0">Forgot password?</a>
			
			<div class="pull-right">
				<a href="#" class="btn btn-default">Reset</a>
				<a href="index.htm" class="btn btn-primary">Log In</a>
			</div>
		</div>
	</div>
 </div>
</body>
	</html>


